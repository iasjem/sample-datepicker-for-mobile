module.exports = {
  plugins: [require('autoprefixer')({//补全前缀
    	overrideBrowserslist: ['last 20 versions']
  })]
}